#ifdef RGBD_CONTROL_EXPORTS
#	define CGV_EXPORTS
#endif

#include <cgv/config/lib_begin.h>
